// =============================================
//  ORBIT TRAINING & DEVELOPMENT — Main JS
// =============================================

document.addEventListener('DOMContentLoaded', () => {

  // ── 1. JS Ready (Scroll Reveal) ──────────────
  document.body.classList.add('js-ready');
  document.querySelectorAll('.fade-up').forEach(el => el.classList.add('animate'));
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('vis'); observer.unobserve(entry.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));

  // ── 2. Nav Scroll ────────────────────────────
  const nav = document.getElementById('nav');
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  });

  // ── 3. Mobile Menu ───────────────────────────
  const hamburger = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobileNav');
  hamburger?.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    mobileNav.classList.toggle('open');
    document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
  });
  mobileNav?.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      hamburger.classList.remove('open');
      mobileNav.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  // ── 4. FAQ Accordion (Listeners are attached dynamically in renderFAQs) ──

  // ── 5. Curriculum Module Accordion ───────────
  document.querySelectorAll('.cd-module-header').forEach(header => {
    header.addEventListener('click', () => {
      const mod = header.closest('.cd-module');
      const isOpen = mod.classList.contains('open');
      document.querySelectorAll('.cd-module.open').forEach(el => el.classList.remove('open'));
      if (!isOpen) mod.classList.add('open');
    });
  });

  // ── 6. Course Tabs ───────────────────────────
  document.querySelectorAll('.course-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.course-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.course-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      const panel = document.getElementById(tab.dataset.tab);
      if (panel) panel.classList.add('active');
    });
  });

  // ── 7. Counter Animation ─────────────────────
  const counters = document.querySelectorAll('[data-count]');
  const counterObs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count);
        const dur = 2000;
        const step = target / (dur / 16);
        let current = 0;
        const update = () => {
          current = Math.min(current + step, target);
          el.textContent = Math.floor(current).toLocaleString('en-IN') + '+';
          if (current < target) requestAnimationFrame(update);
        };
        update();
        counterObs.unobserve(el);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(el => counterObs.observe(el));

  // ── 8. Drag-to-Scroll Reviews ────────────────
  const reviewsGrid = document.querySelector('.reviews-grid');
  if (reviewsGrid) {
    let isDown = false, startX, scrollLeft;
    reviewsGrid.addEventListener('mousedown', e => { isDown = true; reviewsGrid.classList.add('active'); startX = e.pageX - reviewsGrid.offsetLeft; scrollLeft = reviewsGrid.scrollLeft; });
    reviewsGrid.addEventListener('mouseleave', () => { isDown = false; });
    reviewsGrid.addEventListener('mouseup', () => { isDown = false; });
    reviewsGrid.addEventListener('mousemove', e => { if (!isDown) return; e.preventDefault(); const x = e.pageX - reviewsGrid.offsetLeft; const walk = (x - startX) * 2; reviewsGrid.scrollLeft = scrollLeft - walk; });
  }

  // ── 9. Modal Handling ────────────────────────
  const modal = document.getElementById('enrollModal');
  const modalClose = document.getElementById('modalClose');
  const modalCourse = document.getElementById('modalCourseName');

  window.openEnrollModal = (courseName) => {
    if (modal) {
      if (modalCourse) modalCourse.textContent = courseName || 'this course';
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  };
  modalClose?.addEventListener('click', closeModal);
  modal?.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  function closeModal() {
    modal?.classList.remove('open');
    document.body.style.overflow = '';
  }
  
  const brochureModal = document.getElementById('brochureModal');
  const brochureModalClose = document.getElementById('brochureModalClose');
  const brochureCourse = document.getElementById('brochureCourseName');
  const brochureCourseInput = document.getElementById('brochureCourseInput');
  let currentBrochurePdfPath = '';

  window.openBrochureModal = (courseName, pdfPath) => {
    if (brochureModal) {
      if (brochureCourse) brochureCourse.textContent = courseName || 'this course';
      if (brochureCourseInput) brochureCourseInput.value = courseName || 'this course';
      currentBrochurePdfPath = pdfPath;
      brochureModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  };
  brochureModalClose?.addEventListener('click', closeBrochureModal);
  brochureModal?.addEventListener('click', e => { if (e.target === brochureModal) closeBrochureModal(); });
  function closeBrochureModal() {
    brochureModal?.classList.remove('open');
    document.body.style.overflow = '';
  }

  document.addEventListener('keydown', e => { 
    if (e.key === 'Escape') {
      closeModal();
      closeBrochureModal();
    }
  });

  // ── 10. Toast Notification ───────────────────
  window.showToast = (msg, type = '') => {
    let toast = document.querySelector('.toast');
    if (!toast) { toast = document.createElement('div'); toast.className = 'toast'; document.body.appendChild(toast); }
    toast.textContent = msg;
    toast.className = `toast ${type}`;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3200);
  };

  // ── 11. Hero Form Submit ──────────────────────
  const web3formsKey = '8f07fdb8-9b32-4e5d-818d-0b2459252974';
  const heroForm = document.getElementById('heroForm');
  heroForm?.addEventListener('submit', async e => {
    e.preventDefault();
    if (!heroForm.checkValidity()) {
      heroForm.reportValidity();
      return;
    }
    const btn = heroForm.querySelector('.hf-submit');
    btn.textContent = 'Submitting...';
    btn.disabled = true;
    const formData = new FormData(heroForm);
    formData.append('access_key', web3formsKey);
    formData.append('subject', 'New Lead from Hero Form');
    try {
      const response = await fetch('https://api.web3forms.com/submit', { method: 'POST', body: formData });
      if (!response.ok) throw new Error('Failed to submit');
      heroForm.innerHTML = `
        <div class="hf-success" style="display:block">
          <div class="big-emoji">🎉</div>
          <h3>You're All Set!</h3>
          <p>Our counsellor will call you within 24 hours. Check your WhatsApp for a confirmation message.</p>
        </div>`;
    } catch(err) {
      btn.textContent = 'Submit';
      btn.disabled = false;
      showToast('⚠️ Error submitting form. Please try again.', 'error');
    }
  });

  // ── 12. Contact Form Submit ───────────────────
  const contactForm = document.getElementById('contactForm');
  contactForm?.addEventListener('submit', async e => {
    e.preventDefault();
    if (!contactForm.checkValidity()) {
      contactForm.reportValidity();
      return;
    }
    const btn = contactForm.querySelector('.cf-submit');
    btn.textContent = 'Sending...';
    btn.disabled = true;
    const formData = new FormData(contactForm);
    formData.append('access_key', web3formsKey);
    formData.append('subject', 'New Contact Form Submission');
    try {
      const response = await fetch('https://api.web3forms.com/submit', { method: 'POST', body: formData });
      if (!response.ok) throw new Error('Failed to submit');
      btn.textContent = '✓ Message Sent!';
      showToast('✅ Your message has been received! We will contact you shortly.', 'success');
      setTimeout(() => { btn.textContent = 'Send Message'; btn.disabled = false; contactForm.reset(); }, 3000);
    } catch(err) {
      btn.textContent = 'Send Message';
      btn.disabled = false;
      showToast('⚠️ Error sending message. Please try again.', 'error');
    }
  });

  // ── 13. Modal Enroll Form ────────────────────
  const modalForm = document.getElementById('modalForm');
  modalForm?.addEventListener('submit', async e => {
    e.preventDefault();
    if (!modalForm.checkValidity()) {
      modalForm.reportValidity();
      return;
    }
    const btn = modalForm.querySelector('button[type=submit]');
    btn.textContent = 'Submitting...';
    btn.disabled = true;
    const formData = new FormData(modalForm);
    formData.append('access_key', web3formsKey);
    formData.append('subject', 'New Course Enrollment Request');
    try {
      const response = await fetch('https://api.web3forms.com/submit', { method: 'POST', body: formData });
      if (!response.ok) throw new Error('Failed to submit');
      closeModal();
      showToast('🎉 Enrollment request received! We\'ll contact you within 24 hours.', 'success');
      modalForm.reset();
      btn.textContent = 'Submit Enrollment';
      btn.disabled = false;
    } catch(err) {
      btn.textContent = 'Submit Enrollment';
      btn.disabled = false;
      showToast('⚠️ Error submitting form. Please try again.', 'error');
    }
  });

  // ── 13.5. Brochure Form Submit ───────────────
  const brochureForm = document.getElementById('brochureForm');
  brochureForm?.addEventListener('submit', async e => {
    e.preventDefault();
    if (!brochureForm.checkValidity()) {
      brochureForm.reportValidity();
      return;
    }
    const btn = brochureForm.querySelector('button[type=submit]');
    btn.textContent = 'Verifying...';
    btn.disabled = true;
    const formData = new FormData(brochureForm);
    formData.append('access_key', web3formsKey);
    formData.append('subject', 'New Brochure Download Lead');
    try {
      const response = await fetch('https://api.web3forms.com/submit', { method: 'POST', body: formData });
      if (!response.ok) throw new Error('Failed to submit');
      closeBrochureModal();
      showToast('✅ Details verified. Downloading brochure...', 'success');
      brochureForm.reset();
      btn.textContent = 'Download PDF';
      btn.disabled = false;
      // Trigger actual download
      const courseName = brochureCourseInput?.value || 'Course';
      if (currentBrochurePdfPath) {
        downloadPDF(currentBrochurePdfPath, courseName);
      }
    } catch(err) {
      btn.textContent = 'Download PDF';
      btn.disabled = false;
      showToast('⚠️ Error submitting form. Please try again.', 'error');
    }
  });

  // ── 14. Certificate Verify ───────────────────
  const certBtn = document.getElementById('certVerifyBtn');
  const certInput = document.getElementById('certInput');
  certBtn?.addEventListener('click', () => {
    const val = certInput?.value.trim();
    if (!val) { showToast('⚠️ Please enter a certificate ID.', 'error'); return; }
    certBtn.textContent = 'Verifying...';
    certBtn.disabled = true;
    setTimeout(() => {
      showToast('❌ Certificate not found. Please check the ID and try again.', 'error');
      certBtn.textContent = 'Verify';
      certBtn.disabled = false;
    }, 1500);
  });

  // ── 15. PDF Download Fallback ────────────────
  window.downloadPDF = async (path, courseName) => {
    try {
      const response = await fetch(path, { method: 'HEAD' });
      if (response.ok) {
        const a = document.createElement('a');
        a.href = path;
        a.download = courseName.replace(/\s+/g,'-').toLowerCase() + '-brochure.pdf';
        a.target = '_blank';
        a.click();
        showToast(`📄 Downloading ${courseName} brochure...`, 'success');
      } else {
        showToast('⚠️ Brochure not available. Please contact us for more information.', 'error');
      }
    } catch (err) {
      showToast('⚠️ Brochure not available. Please contact us for more information.', 'error');
    }
  };

  // ── 16. Top Offer Poster Lightbox Modal ─────────
  const posterModal = document.getElementById('posterModal');
  const posterCard = document.getElementById('openPosterModal');
  const posterModalClose = document.getElementById('posterModalClose');

  if (posterModal && posterCard) {
    posterCard.addEventListener('click', () => {
      posterModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });

    const closePosterModal = () => {
      posterModal.classList.remove('open');
      document.body.style.overflow = '';
    };

    posterModalClose?.addEventListener('click', closePosterModal);
    posterModal.addEventListener('click', e => {
      if (e.target === posterModal) closePosterModal();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && posterModal.classList.contains('open')) {
        closePosterModal();
      }
    });
  }

});

// ── 16. Render Functions (called from HTML) ──────
function renderCourseCards(category, containerId) {
  if (typeof COURSES_DATA === 'undefined') return;
  const container = document.getElementById(containerId);
  if (!container) return;
  const courses = COURSES_DATA[category];
  container.innerHTML = courses.map(c => `
    <div class="course-card fade-up" style="--cc:${c.accentColor}">
      <div class="cc-header">
        <span class="cc-icon">${c.icon}</span>
        <span class="cc-tag ${c.tagColor}">${c.tag}</span>
      </div>
      <div class="cc-name">${c.name}</div>
      <div class="cc-meta">
        <span class="cc-dur">⏱ ${c.duration}</span>
        <span class="cc-lvl">📶 ${c.level}</span>
      </div>
      <div class="cc-desc">${c.description}</div>

      <div class="cc-actions">
        <a href="course.html?id=${c.id}" class="cc-btn-detail">📖 View Details</a>
        <button class="cc-btn-pdf" onclick="openBrochureModal('${c.name}', '${c.pdfPath}')">📥 Brochure</button>
      </div>
    </div>
  `).join('');
  // Re-observe new fade-up elements
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('vis'); obs.unobserve(entry.target); }
    });
  }, { threshold: 0.08 });
  container.querySelectorAll('.fade-up').forEach(el => obs.observe(el));
}

function renderTrainers() {
  if (typeof TRAINERS_DATA === 'undefined') return;
  const container = document.getElementById('trainersGrid');
  if (!container) return;
  container.innerHTML = TRAINERS_DATA.map(t => `
    <div class="tr-card fade-up">
      <div class="tr-avatar">${t.initials}</div>
      <div class="tr-name">${t.name}</div>
      <div class="tr-role">${t.role}</div>
      <span class="tr-badge">${t.badge}</span>
      <div class="tr-exp">${t.exp} Experience</div>
    </div>
  `).join('');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('vis'); obs.unobserve(entry.target); } });
  }, { threshold: 0.1 });
  container.querySelectorAll('.fade-up').forEach(el => obs.observe(el));
}

function renderReviews() {
  if (typeof REVIEWS_DATA === 'undefined') return;
  const container = document.getElementById('reviewsGrid');
  if (!container) return;
  container.innerHTML = REVIEWS_DATA.map(r => `
    <div class="rv-card">
      <div class="rv-header">
        <span class="rv-stars">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</span>
        <span class="rv-date">${r.date}</span>
      </div>
      <div class="rv-text">"${r.text}"</div>
      <div class="rv-author">
        <div class="rv-name">${r.name}</div>
        <div class="rv-role">${r.role}</div>
        <div class="rv-company">@ ${r.company}</div>
      </div>
    </div>
  `).join('');
}

function renderFAQs() {
  if (typeof FAQS_DATA === 'undefined') return;
  const container = document.getElementById('faqList');
  if (!container) return;
  container.innerHTML = FAQS_DATA.map((f, i) => `
    <div class="faq-item">
      <button class="faq-q">${f.q}<span class="faq-icon">+</span></button>
      <div class="faq-ans"><p>${f.a}</p></div>
    </div>
  `).join('');
  // Re-attach FAQ listeners
  container.querySelectorAll('.faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const isOpen = item.classList.contains('open');
      container.querySelectorAll('.faq-item.open').forEach(el => el.classList.remove('open'));
      if (!isOpen) item.classList.add('open');
    });
  });
}

// ── 17. Course Detail Page ───────────────────
function loadCourseDetail() {
  if (typeof COURSES_DATA === 'undefined') return;
  const params = new URLSearchParams(window.location.search);
  const courseId = params.get('id');
  if (!courseId) { window.location.href = 'index.html'; return; }
  const course = ALL_COURSES.find(c => c.id === courseId);
  if (!course) { window.location.href = 'index.html'; return; }

  // Update page title
  document.title = `${course.name} Course | Orbit Training & Development`;

  // Breadcrumb
  const breadcrumb = document.getElementById('cdBreadcrumb');
  if (breadcrumb) breadcrumb.innerHTML = `<a href="index.html">Home</a><span>›</span><a href="index.html#courses">Courses</a><span>›</span>${course.name}`;

  // Course info
  setEl('cdTitle', course.name);
  setEl('cdDesc', course.description);
  setEl('cdIcon', course.icon);
  setEl('cdDuration', `⏱ ${course.duration}`);
  setEl('cdLevel', `📶 ${course.level}`);
  setEl('cdStudents', `👥 ${course.students.toLocaleString('en-IN')}+ Students`);
  setEl('cdRating', `⭐ ${course.rating}/5 (${course.reviews} reviews)`);

  // Top accent color
  document.querySelectorAll('.cd-accent').forEach(el => el.style.color = course.accentColor);

  // Highlights
  const hlContainer = document.getElementById('cdHighlights');
  if (hlContainer) {
    hlContainer.innerHTML = course.highlights.map(h => `<div class="cd-highlight-item">${h}</div>`).join('');
  }

  // Curriculum
  const curContainer = document.getElementById('cdCurriculum');
  if (curContainer) {
    curContainer.innerHTML = course.curriculum.map((mod, i) => `
      <div class="cd-module ${i === 0 ? 'open' : ''}">
        <div class="cd-module-header">
          <span class="cd-module-name">${mod.module}</span>
          <span class="cd-module-icon">+</span>
        </div>
        <div class="cd-module-topics">
          <ul>${mod.topics.map(t => `<li>${t}</li>`).join('')}</ul>
        </div>
      </div>
    `).join('');
    // Attach accordion listeners
    curContainer.querySelectorAll('.cd-module-header').forEach(header => {
      header.addEventListener('click', () => {
        const mod = header.closest('.cd-module');
        const isOpen = mod.classList.contains('open');
        curContainer.querySelectorAll('.cd-module.open').forEach(el => el.classList.remove('open'));
        if (!isOpen) mod.classList.add('open');
      });
    });
  }

  // Trainer info
  setEl('cdTrainerInitials', course.trainerRole.split(' ').slice(0,2).map(w=>w[0]).join(''));
  setEl('cdTrainerName', course.trainer);
  setEl('cdTrainerRole', course.trainerRole);
  setEl('cdTrainerExp', course.trainerExp + ' Experience');

  // Pricing card info
  setEl('cdpCourseName', course.name);
  setEl('cdpDuration', course.duration);
  setEl('cdpLevel', course.level);

  // Enroll / Download buttons
  const enrollBtn = document.getElementById('cdpEnrollBtn');
  if (enrollBtn) {
    enrollBtn.addEventListener('click', () => window.openEnrollModal(course.name));
  }
  const pdfBtn = document.getElementById('cdpPdfBtn');
  if (pdfBtn) {
    pdfBtn.addEventListener('click', () => window.openBrochureModal(course.name, course.pdfPath));
  }
  // Page-level PDF download
  const pagePdfBtn = document.getElementById('cdPagePdfBtn');
  if (pagePdfBtn) {
    pagePdfBtn.addEventListener('click', () => window.openBrochureModal(course.name, course.pdfPath));
  }
}

function setEl(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}
